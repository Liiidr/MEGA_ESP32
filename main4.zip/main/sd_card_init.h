#ifndef _SD_CARD_INIT_H
#define _SD_CARD_INIT_H




void app_sdcard_init(void);





#endif
