#ifndef _JOSHVM_ESP32_TIMER_H_
#define _JOSHVM_ESP32_TIMER_H_





void joshvm_vad_timer(void);

#endif